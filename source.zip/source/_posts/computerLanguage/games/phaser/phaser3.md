---
layout: "post"
title: "Phaser3"
date: "2019-6-22 14:47:36"
categories: [web,games]
tags: [Computer Language, web,games,Phaser3]
---

## 什么是Phaser

Phaser是一个HTML5游戏框架，它的目的是辅助开发者真正快速地制作强大的、跨浏览器的HTML5游戏。 做这个框架，主要是想发掘现代浏览器（兼及桌面和移动两类系统）的优点，。对浏览器的唯一要求是，支持画布（canvas）标签。

## 下载


---

参考视频: http://www.phaser.io/tutorials/making-your-first-phaser-3-game-chinese