---
layout: "post"
title: "Ofbiz"
date: "2019-10-23 10:29"
categories: framework,Ofbiz
tags: [Computer Language, framework,Ofbiz]
---

# Ofbiz权限设计

## 相关表

## 用户登录表 `user_login` 

## 安全组列表 `security_group`

## 登录用户和安全组关系表 `user_login_security_group`

## 权限组列表 `security_permission`

'security_permission'中的数据是在 `xxxSecurityPermissionSeedData.xml`文件中配置的，`xxx`表示组件名称


## 安全组与权限关系表 `security_group_permission `

