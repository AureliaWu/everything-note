---
layout: "post"
title: "泰语基础"
date: "2019-10-8 15:50:11"
categories: [natural language, Dai]
tags: [natural language, Dai]
---

## 泰语入门




---

参考视频: https://www.bilibili.com/video/av2204155?t=1085